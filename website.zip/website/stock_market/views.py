from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score    
# Create your views here.



def indexView(request):
    return render(request,'index.html')

@login_required
def dashboardView(request):
    return render(request,'dashboard.html')


def registerView(request):
    if request.method == "POST":
        form =UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login_url')
    else:
        form = UserCreationForm()
    return render(request,'registration/register.html',{'form':form})

def predict(request):
    if (request.method == 'POST'):
        Open = int(request.POST['Open'])
        High = int(request.POST['High'])
        Low = int(request.POST['Low'])
        Last = int(request.POST['Last'])
        Close = int(request.POST['Close'])
        Total_Trade_Quantity = int(request.POST['Total'])
        
        df = pd.read_csv(r"stock_market/static/datasets/stockmarket.csv")
        x=df.drop(["Date","Turnover"],axis=1)
        y=df[["Turnover"]]
        reg=linear_model.LinearRegression()
        xtrain,xtest,ytrain,ytest=train_test_split(x,y,test_size=0.2,random_state=0)
        reg.fit(xtrain,ytrain)
        #ypred=reg.predict(xtest)
        #accuracy=cross_val_score(estimator=reg,X=xtrain,Y=ytrain,cv=20)
        #mean_accuracy=accuracy.mean()
        model= reg
        prediction=np.array([[Open,High,Low,Last,Close,Total_Trade_Quantity]])
        pred= model.predict(prediction)
        #hp = predict(Open=Open,High=High,Low=Low,Last=Last,Close=Close,Total_Trade_Quantity=Total_Trade_Quantity)
        #hp.save()
        
        
        return render(request,'predict.html',{'Turnover':pred})
    else:
        return render(request,'dashboard.html')

