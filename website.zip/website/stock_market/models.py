from django.db import models

# Create your models here.
class predict(models.Model):
    Open= models.IntegerField()
    High= models.IntegerField()
    Low= models.IntegerField()
    Last= models.IntegerField()
    Close= models.IntegerField()
    Total_Trade_Quantity= models.IntegerField()

