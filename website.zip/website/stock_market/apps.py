from django.apps import AppConfig


class StockMarketConfig(AppConfig):
    name = 'stock_market'
    
    
from flask import Flask,render_template,request
import pickle
import numpy as np

app = Flask(__name__)

@app.route('/')
def man():
    return render_template('dashboard.html')

@app.route('/predict',methods=['POST'])
def dashboard():
    data1 = request.frorm['a']
    data2 = request.frorm['b']
    data3 = request.frorm['c']
    data4 = request.frorm['d']
    data5 = request.frorm['e']
    data6 = request.frorm['f']
    arr=np.array([[data1,data2,data3,data4,data5,data6,]])
    pred =model.predict(arr)
    return render_template('index.html',data=pred)

if __name__=="__main__":
    app.run(debug=True)